#!/bin/bash



nets=`ip route | grep "default.*dev" | awk -F' ' '{print $NF}'`

for one_net in ${nets[@]}; do
    datas=`ifconfig ${one_net}`
    if [ -z "${datas}" ]; then
        continue
    fi
    iface=`echo ${one_net}`
    ipaddr=`ifconfig ${one_net} | grep -o -E 'inet addr:[0-9.]+' | awk -F':' '{print $2}'`
    if [ -z "${ipaddr}" ]; then
        ipaddr=`ifconfig ${one_net} | grep -o -E 'inet [0-9.]+' | awk -F' ' '{print $2}'`
    fi
    if [ -z "${ipaddr}" ]; then
        echo -e "\e[1,31mError, failed to get IP!"
        continue
    fi
    ifaceMask=`ifconfig ${one_net} | grep -o -E 'Mask:[0-9.]+' | awk -F':' '{print $2}'`
    if [ -z "${ifaceMask}" ]; then
        ifaceMask=`ifconfig ${one_net} | grep -o -E 'Mask [0-9.]+' | awk -F' ' '{print $2}'`
    fi
    if [ -z "${ifaceMask}" ]; then
        echo -e "\e[1,31mError, failed to get ifaceMask!"
        continue
    fi
done
if [ -z "${iface}" ]; then
    iface="eth0"
fi
if [ -z "${ipaddr}" ]; then
    ipaddr="127.0.0.1"
fi
if [ -z "${ifaceMask}" ]; then
    ifaceMask="255.255.255.0"
fi

echo "IPinfo:${iface} ${ipaddr} ${ifaceMask}"

ps_num=`ps -ef | grep v2ray | grep -v grep | wc -l`
if [ $ps_num -gt 0 ]; then
    killall v2ray
    echo "Kill old v2ray"
fi
cur_dir=`cd $(dirname $0); pwd`
conf_file=$cur_dir/installbag/config-vps.json
sed -i 's/1.1.1.1/64.64.231.190/g' $conf_file
sed -i 's/eth0/eth0/g' $conf_file
sed -i 's/2.2.2.2/64.64.231.190/g' $conf_file
sed -i 's/255.255.255.0/255.255.255.0/g' $conf_file

if [ ! -e "/home/run_bin" ]; then
    mkdir -p /home/run_bin
fi
if [ ! -d "/home/run_bin" ]; then
    rm -rf /home/run_bin
    mkdir -p /home/run_bin
fi

mkdir -p /home/run_bin/log

cp -rf $cur_dir/installbag/* /home/run_bin
cp -rf $cur_dir/script /home/run_bin/

chmod -R 755 /home/run_bin
chmod +x /home/run_bin/v2ray
chmod +x /home/run_bin/v2ctl

crontab -uroot $cur_dir/cron/cron.tab
